<?php
include_once("include/config.php");
include_once("include/auth.lib.php");
include_once("include/function.php");

list($status, $user) = auth_get_status();

if($status == AUTH_LOGGED & auth_get_option("TRANSICTION METHOD") == AUTH_USE_LINK){
	$link = "?uid=".$_GET['uid'];
}else	$link = '';

?>

<html>
	<head>
    	<?php $us=get_user_detail($user[id]); ?>
    	<link type="text/css" rel="stylesheet" href="style.css">
		<title><?php echo("".$us[name]." ".$us[surname]."") ?></title>
	</head>
	<body>
	<?php include'top.php'; ?>
    	<div id="corpo">
			
				<?php
					if(!($status == AUTH_LOGGED && $user[type]=='2')){
						header("Refresh: 5;URL=panel".$user[type].".php");
						echo '<div id="red_message">Non hai i diritti per visualizzare la pagina</div>';
					}
                    else{
                    	echo(" 
                        	<div id='function_bar'>
                        		<div id='function_button'><a href='payments_list.php?id=".$user[id]."&state=-1&deadline=-1' id='function_text'>Lista pagamenti</a></div>
                        		<div id='function_button'><a href='exercise_list.php?mode=executed' id='function_text'>Esercizi svolti</a></div>                                
                        		<div id='function_button'><a href='exercise_list.php?mode=assigned' id='function_text'>Esercizi assegnati</a></div>                                
                        		<div id='function_button'><a href='Chart/graphic_progress.php?mode=w' id='function_text'>Progressi</a></div>                                
								<div id='function_button'><a href='alter_user.php?mode=data' id='function_text'>Modifica dati</a></div>                                
                        		<div id='function_button'><a href='alter_user.php?mode=password' id='function_text'>Modifica password</a></div> 
                        		<div id='function_button'><a href='alter_user.php?mode=weight' id='function_text'>Aggiorna peso</a></div>                                
								<div id='red_function_button'><a href='logout.php' id='function_text'>Logout</a></div>


                            </div>
                            <div id='contenuto'>
                            	<div id=titolo_scheda>
                                	<a id='name'>".$us[name]." ".$us[surname]."		</a><a id = type>CLIENTE</a>");
                                echo("</div>
                                <div id=contenuto_scheda>
                                	<table id=detail_table>
                                    	<tr>
                                        	<th align=left>Nome</th>
                                            <td>".$us[name]."
                                        </tr>
                                        <tr>
                                        	<th align=left>Cognome</th>
                                            <td>".$us[surname]."</td>
                                        </tr>
                                        <tr>
                                        	<th align=left>E-mail</th>
                                            <td>".$us[mail]."</td>
                                        </tr>
                                        <tr>
                                        	<th align=left>Data di registrazione</th>
                                            <td>".date('d M Y',$us[reg_date])."</td>
                                        </tr>
                                        <tr>
                                        	<th align=left>Attivazione</th>");
                                            if($us[activated]==1)echo("<td>Effettuata</td>");
                                            else echo("<td>Non effettuata</td>");
                                        echo("</tr>");
                                        
                                        if($us[type]==2){
                                        	echo("
                                        <tr>
                                        	<th align=left>Indirizzo</th>
                                            <td>".$us[address]."</td>
                                        </tr>
                                        <tr>
                                        	<th align=left>Telefono</th>
                                            <td>".$us[telephone]."</td>
                                        </tr>
                                        <tr>
                                        	<th align=left>Eta'</th>
                                            <td>".$us[age]."</td>
                                        </tr>
                                        <tr>
                                        	<th align=left>Altezza</th>
                                            <td>".$us[height]."</td>
                                        </tr>
                                        <tr>
                                        	<th align=left>Peso al momento dell'iscrizione</th>
                                            <td>".$us[o_weight]."</td>
                                        </tr>
                                        <tr>
                                        	<th align=left>Peso attuale</th>
                                            <td>".$us[a_weight]."</td>
                                        </tr>
                                            ");
                                            
                                        }
                                    echo("</table>
                                </div>
                                ");                              
                          	echo("</div>");
             		} 
?>
        	
		</div>
	<?php include'bottom.php'; ?>
	</body>
</html>


