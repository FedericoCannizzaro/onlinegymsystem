<?php
header("Refresh: 0;URL=index.php");
?>